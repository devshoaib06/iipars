<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class manage_ebook extends CI_Controller
{
	public function __construct()
    {
          parent::__construct();
           $this->load->database();

	}

	public function invitation_for_ebook_form()
	{
		
		$json    			=  file_get_contents('php://input');
		$obj     			=  json_decode($json);



		$nam = $obj->nam;
		$designation = $obj->designation;
		$phone = $obj->phone;
		$email = $obj->email;
		$wp = $obj->wp;
		$address = $obj->address;
		$subject = $obj->subject;
		$book_title = $obj->book_title;
		$short_description = $obj->short_description;
	    $created_on=date('Y-m-d');


	    	$data= array(
    		     'nam'=>$nam,
    		     'email'=>$email,
    		     'phone'=>$phone,
    		     'wp'=>$wp,
    		     'subject'=>$subject,
                 'designation'=>$designation,
                 'address'=>$address,
                 'book_title'=>$book_title,
    		     'short_description'=>$short_description,
    		     'created_on'=>$created_on
    	             );


	    	$this->db->insert('tbl_invite_for_ebook',$data);

	    	$result=1;

			echo json_encode(array('result'=>$result));
		
   
         



	}


	public function purchase_your_book()
	{

		$purchase_ebook=[];

		$ebook_list=$this->admin_model->selectAll('tbl_ebook');

		foreach($ebook_list as $book)
		{
			$ebookArr['id']= $book->id;
			$ebookArr['title']= $book->title;
			$ebookArr['image']= $book->image;

			array_push($purchase_ebook,$ebookArr);

		}

    echo json_encode(array('purchase_ebook'=>$purchase_ebook));


	}


	public function buy_now()
	{
		$json    			=  file_get_contents('php://input');
		$obj     			=  json_decode($json);


		    $data=array(
			     'ebook_id'=>'',
			     'user_id'=>'',
			     'purchase_date'=>date('Y-m-d'),
		            );

              $this->db->insert('tbl_ebook_purchase',$data);
              $result=1;

			echo json_encode(array('result'=>$result));
	}


	
}



 ?>