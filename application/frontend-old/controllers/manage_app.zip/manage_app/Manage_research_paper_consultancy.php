<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class manage_research_paper_consultancy extends CI_Controller
{
	public function __construct()
    {
          parent::__construct();
           $this->load->database();

	}

	public function research_paper_consul_form()
	{
		
		$json    			=  file_get_contents('php://input');
		$obj     			=  json_decode($json);



		$nam = $obj->nam;
		$email = $obj->email;
		$phone = $obj->phone;
		$wp = $obj->wp;
		$subject = $obj->subject;
		$designation = $obj->designation;
		$subject2 = $obj->subject2;
		$specialisation = $obj->specialisation;
		$mphil = $obj->mphil;
		$nopaper = $obj->nopaper;
		$in_words = $obj->in_words;
		$total_amount = $obj->total_amount;
		$t_amount_words = $obj->t_amount_words;
	    $created_on=date('Y-m-d');


	    $data= array(
			 'nam'=>$nam,
			 'email'=>$email,
			 'phone'=>$phone,
			 'wp'=>$wp,
			 'subject'=>$subject,
			 'designation'=>$designation,
			 'subject2'=>$subject2,
			 'specialisation'=>$specialisation,
			 'mphil'=>$mphil,
			 'nopaper'=>$nopaper,
			 'in_words'=>$in_words,
			 'total_amount'=>$total_amount,
			 't_amount_words'=>$t_amount_words,
			 'created_on'=>$created_on

		            );


	    	$this->db->insert('tbl_research_paper_consul_form',$data);

	    	$result=1;

			echo json_encode(array('result'=>$result));
		
   
         



	}


	public function research_guideline()
	{

		$guideline=[];

		$research_guide=$this->admin_model->selectAll('tbl_research_guideline');

		foreach($research_guide as $guide)
		{
			$guideArr['video_link']= $guide->video_link;
			$guideArr['title']= $guide->title;
			$guideArr['description']= $guide->description;

			array_push($guideline,$guideArr);

		}

    echo json_encode(array('guideline'=>$guideline));


	}




	
}



 ?>