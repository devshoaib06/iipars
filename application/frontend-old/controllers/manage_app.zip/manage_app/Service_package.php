<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class service_package extends CI_Controller
{
	public function __construct()
    {
          parent::__construct();
           $this->load->database();

	}

	public function service_package_data()
	{
		$services_package=[];

		$service_type=  $this->common_model->common($table_name = 'tbl_examination_type', $field = array(), $where = array('status'=>'active'), $where_or = array(), $like = array(), $like_or = array(), $order = array(), $start = '', $end = '');

		foreach($service_type as $type)
		{
			$service=  $this->common_model->common($table_name = 'tbl_examination', $field = array(), $where = array('examination_type_id'=>$type->examination_type_id), $where_or = array(), $like = array(), $like_or = array(), $order = array(), $start = '', $end = '');
			$service_array=[];

			foreach($service as $ser)
			{

				$serviceArr['service_name']= $ser->examination_name;

				array_push($service_array,$serviceArr);
			}

			$ser_typArr['type_name']= $type->examination_type;
			$ser_typArr['service_array']= $service_array;
			array_push($services_package,$ser_typArr);


		}

 	echo json_encode(array('services_package'=>$services_package));

		



	}


	public function subject_list()
	{
		$subject_details=[];

		$subject=  $this->common_model->common($table_name = 'tbl_kpo', $field = array(), $where = array(), $where_or = array(), $like = array(), $like_or = array(), $order = array(), $start = '', $end = '');

		foreach($subject as $sub)
		{
			$subArr['sub_name']= $sub->kpo_name;
			$subArr['image']= base_url().'assets/upload/subject_image/'.$sub->subject_image;

			array_push($subject_details, $subArr);
		}

 	echo json_encode(array('subject_details'=>$subject_details));

	}
}



 ?>