<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class sign_up extends CI_Controller
{
	public function __construct()
    {
          parent::__construct();
           $this->load->database();

	}

	public function signup_form()
	{
		$signup_form_details=[];
		

		$subject = $this->common_model->common($table_name = 'tbl_kpo', $field = array(), $where = array('status'=>'active'), $where_or = array(), $like = array(), $like_or = array(), $order = array(), $start = '', $end = '');

		foreach($subject as $row_subject)
		{
			
			$subArr['kpo_id']= $row_subject->kpo_id;
			$subArr['kpo_name']= $row_subject->kpo_name;
			

			array_push($signup_form_details,$subArr);

		}

		// print_r($all_news_feed);
	

 	echo json_encode(array('signup_form_details'=>$signup_form_details));
         



	}

	public function create_account()
	{
		$json =  file_get_contents('php://input');
		$obj  =  json_decode($json);


		$full_name = $obj->full_name;
		$email = $obj->email;
		$mobile = $obj->mobile;
		$password = $obj->password;
		$confirm_pass = $obj->confirm_pass;
		$subject = $obj->subject;
		$created_on=date('Y-m-d H:i:s');



		$code= mt_rand(100000, 999999);
		$user_type_id="ST".$code;

		$email_check=$this->common_model->common($table_name = 'tbl_user', $field = array(), $where = array('login_email'=>$email), $where_or = array(), $like = array(), $like_or = array(), $order = array(), $start = '', $end = '');

		if(count($email_check)>0)
		{
		 	$result = "email_exist";
		   	echo json_encode(array('result'=>$result)); 
		 	
		}
		else{
			$data=array(
						'user_type_id'=>'2',
						'user_unique_id'=>$user_type_id,
						'first_name'=>$full_name,
						'login_email'=>$email,
						'login_pass'=>$confirm_pass,
						'created_on'=>$created_on,
						'subject_id'=>$subject,
						'mobile'=>$mobile
					   );

			 $this->db->insert('tbl_user',$data);
			$result=1;
            echo json_encode(array('result'=>$result));
		}
		


		     
       

	}


	public function login_action()
	{
		$json =  file_get_contents('php://input');
		$obj  =  json_decode($json);


		$email = $obj->phone_number;
		$password = $obj->password;

		$login_check_email=  $this->common_model->common($table_name = 'tbl_user', $field = array(), $where = array('login_email'=>$email,'login_pass'=>$password,'status'=>'active','user_type_id'=>'2'), $where_or = array(), $like = array(), $like_or = array(), $order = array(), $start = '', $end = '');


		$login_check_mobile=  $this->common_model->common($table_name = 'tbl_user', $field = array(), $where = array('mobile'=>$email,'login_pass'=>$password,'status'=>'active','user_type_id'=>'2'), $where_or = array(), $like = array(), $like_or = array(), $order = array(), $start = '', $end = '');

		if(count($login_check_email)>0)
		{
					 $result=1;
					 $user_id= $login_check_email[0]->user_id;
					  $user_fname= $login_check_email[0]->first_name;
					   $mobile= $login_check_email[0]->mobile;
					    $login_email= $login_check_email[0]->login_email;

                     echo json_encode(array('result'=>$result,'user_id'=>$user_id,'user_fname'=>$user_fname,'mobile'=>$mobile,'login_email'=>$login_email));


		}
		else if(count($login_check_mobile)>0){

					$result=1;
					 $user_id= $login_check_mobile[0]->user_id;
					  $user_fname= $login_check_mobile[0]->first_name;
					   $mobile= $login_check_mobile[0]->mobile;
					    $login_email= $login_check_mobile[0]->login_email;

                     echo json_encode(array('result'=>$result,'user_id'=>$user_id,'user_fname'=>$user_fname,'mobile'=>$mobile,'login_email'=>$login_email));
		}
		else{

					$result=0;
					 $user_id='';
					  $user_fname= '';
					   $mobile= '';
					    $login_email= '';

                     echo json_encode(array('result'=>$result,'user_id'=>$user_id,'user_fname'=>$user_fname,'mobile'=>$mobile,'login_email'=>$login_email));
		}
	}

	public function get_my_profile_details()
	{
		$json =  file_get_contents('php://input');
		$obj  =  json_decode($json);


		$user_id = $obj->user_id;

		$get_profile_details= $this->common_model->common($table_name = 'tbl_user', $field = array(), $where = array('user_id'=>$user_id), $where_or = array(), $like = array(), $like_or = array(), $order = array(), $start = '', $end = '');

		$profile_details_array=array();
		foreach($get_profile_details as $row){

			$rowArray['first_name']= $row->first_name;
			$rowArray['user_unique_id']= $row->user_unique_id;
			$rowArray['mobile']= $row->mobile;
			$rowArray['login_email']= $row->login_email;
			$rowArray['created_on']= $row->created_on;
			$rowArray['subject_id']= $row->subject_id;
			$rowArray['address']= $row->address;

			array_push($profile_details_array, $rowArray);




		}
		echo json_encode(array('profile_details_array'=>$profile_details_array));
	}


	function update_profile_details(){

		$json =  file_get_contents('php://input');
		$obj  =  json_decode($json);


		$user_id = $obj->user_id;
		$user_name = $obj->user_name;
		$user_id = $obj->user_id;
		$email = $obj->email;
		$phone_number = $obj->phone_number;
		$address = $obj->address;

		$update_data= array(
							'first_name'=>$user_name,
							'mobile'=>$phone_number,
							'login_email'=>$email,
							'address'=>$address
						);

		$this->db->where('user_id',$user_id);
		$this->db->update(' tbl_user', $update_data);

		echo json_encode(array('result'=>1));

	}
	function update_password_action()
	{

		$json =  file_get_contents('php://input');
		$obj  =  json_decode($json);


		$user_id = $obj->user_id;
		$old_password = $obj->old_password;
		$new_passwprd = $obj->new_passwprd;
		$confirm_password = $obj->confirm_password;

		$check_old_password= $this->common_model->common($table_name = 'tbl_user', $field = array(), $where = array('login_pass'=>$old_password,'user_id'=>$user_id), $where_or = array(), $like = array(), $like_or = array(), $order = array(), $start = '', $end = '');

		if(count($check_old_password)>0){
					if($old_password==$new_passwprd){
						$result=2;
						}
					else{
						$update_array=array(
											'login_pass'=>$new_passwprd
										);
						$this->db->where('user_id', $user_id);
						$this->db->update('tbl_user', $update_array);
						$result=1;
					}
		}
		else{
			$result=0;

		}

		echo  json_encode(array('result'=>$result));
	}
}



 ?>